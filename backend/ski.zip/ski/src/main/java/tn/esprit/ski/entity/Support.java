package tn.esprit.ski.entity;

public enum Support {
    SKI, SNOWBOARD
}

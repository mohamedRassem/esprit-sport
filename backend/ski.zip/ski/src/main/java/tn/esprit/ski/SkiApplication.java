package tn.esprit.ski;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SkiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkiApplication.class, args);
    }

}

package tn.esprit.ski.entity;

public enum TypeCours {
 COLLECTIF_ENFANT ,
 COLLECTIF_ADULTE ,
 PARTICULIER
}

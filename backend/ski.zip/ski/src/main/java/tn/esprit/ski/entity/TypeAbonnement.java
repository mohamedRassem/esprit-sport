package tn.esprit.ski.entity;

public enum TypeAbonnement {
    ANNUEL , SEMESTRIEL ,MENSUEL
}

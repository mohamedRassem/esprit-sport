package tn.esprit.ski.entity;

public enum Couleur {
    VERT, BLEU, ROUGE, NOIR
}

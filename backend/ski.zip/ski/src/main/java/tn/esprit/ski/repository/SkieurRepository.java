package tn.esprit.ski.repository;

public interface SkieurRepository {
}
